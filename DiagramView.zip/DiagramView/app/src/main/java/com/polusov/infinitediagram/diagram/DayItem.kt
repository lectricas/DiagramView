package com.firstlinesoftware.diabetus.diagram

class DayItem(
    val points: List<DiagramPoint>
)