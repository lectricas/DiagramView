package com.example.apolusov.kotlintest.diagram

data class PixelPoint(
    val x: Float,
    val y: Float
)